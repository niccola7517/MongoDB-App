// db.js
const { MongoClient } = require('mongodb');
require('dotenv').config(); // .env를 참고하여 환경변수 설정

const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri, {
  maxPoolSize: 10, // 연결 풀 크기
  serverSelectionTimeoutMS: 5000, // 서버 선택 타임아웃
  socketTimeoutMS: 45000, // 소켓 타임아웃
});

async function connectToDatabase() {
  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    return client.db(process.env.DB_NAME);
  } catch (err) {
    console.error('Connection error:', err);
    throw err;
  }
}

module.exports = { connectToDatabase, client };