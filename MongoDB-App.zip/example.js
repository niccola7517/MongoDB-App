// example.js (fetch 버전)
const API_BASE_URL = 'http://localhost:3000';

async function example() {
  try {
    // 1. 사용자 생성 (POST /users)
    console.log('\n=== 사용자 생성 ===');
    const createResponse = await fetch(`${API_BASE_URL}/users`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        _id: '6',
        name: { first: 'John', last: 'Doe' },
        email: 'john.doe@example.com',
        age: 30,
        score: 88,
        interests: ['reading', 'coding', 'traveling']
      })
    });
    
    if (!createResponse.ok) {
      throw new Error(`HTTP error! status: ${createResponse.status}`);
    }
    const createdUser = await createResponse.json();
    console.log('Created user:', createdUser);

    // 2. 모든 사용자 조회 (GET /users)
    console.log('\n=== 모든 사용자 조회 ===');
    const getAllResponse = await fetch(`${API_BASE_URL}/users`);
    
    if (!getAllResponse.ok) {
      throw new Error(`HTTP error! status: ${getAllResponse.status}`);
    }
    const allUsers = await getAllResponse.json();
    console.log('All users:', allUsers);

    // 3. 30세 이상 사용자 조회 (클라이언트 필터링)
    console.log('\n=== 30세 이상 사용자 조회 ===');
    const adults = allUsers.filter(user => user.age >= 30);
    console.log('Adults (age >= 30):', adults);

    // 4. 사용자 업데이트 (PUT /users/:id)
    console.log('\n=== 사용자 업데이트 ===');
    const updateResponse = await fetch(`${API_BASE_URL}/users/6`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        age: 31,
        score: 95
      })
    });
    
    if (!updateResponse.ok) {
      throw new Error(`HTTP error! status: ${updateResponse.status}`);
    }
    const updateResult = await updateResponse.json();
    console.log('Update result:', updateResult);

    // 5. 업데이트 확인
    console.log('\n=== 업데이트 확인 ===');
    const updatedUsersResponse = await fetch(`${API_BASE_URL}/users`);
    
    if (!updatedUsersResponse.ok) {
      throw new Error(`HTTP error! status: ${updatedUsersResponse.status}`);
    }
    const updatedUsers = await updatedUsersResponse.json();
    const updatedUser = updatedUsers.find(user => user._id === '6');
    console.log('Updated user:', updatedUser);

    // 6. 사용자 삭제 (DELETE /users/:id)
    console.log('\n=== 사용자 삭제 ===');
    const deleteResponse = await fetch(`${API_BASE_URL}/users/6`, {
      method: 'DELETE'
    });
    
    if (!deleteResponse.ok) {
      throw new Error(`HTTP error! status: ${deleteResponse.status}`);
    }
    const deleteResult = await deleteResponse.json();
    console.log('Delete result:', deleteResult);

    // 7. 삭제 확인
    console.log('\n=== 삭제 확인 ===');
    const finalUsersResponse = await fetch(`${API_BASE_URL}/users`);
    
    if (!finalUsersResponse.ok) {
      throw new Error(`HTTP error! status: ${finalUsersResponse.ok}`);
    }
    const finalUsers = await finalUsersResponse.json();
    console.log('Remaining users count:', finalUsers.length);

  } catch (err) {
    console.error('Error:', err.message);
  } finally {
    console.log('\n=== 테스트 완료 ===');
    process.exit();
  }
}

// 서버가 실행 중인지 확인 후 테스트 실행
async function checkServerAndRun() {
  try {
    const response = await fetch(`${API_BASE_URL}/users`);
    if (!response.ok) {
      throw new Error('Server responded with error');
    }
    console.log('서버 연결 확인 완료');
    example();
  } catch (err) {
    console.error('서버가 실행되지 않았습니다. 먼저 "node app.js"로 서버를 실행해주세요.');
    console.error('에러 상세:', err.message);
    process.exit(1);
  }
}

checkServerAndRun();